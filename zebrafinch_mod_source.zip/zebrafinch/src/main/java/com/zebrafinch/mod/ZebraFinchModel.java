package com.zebrafinch.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Built at 2x resolution; the renderer scales it by 0.25 (half of the previous 0.5).
 * Male-only parts (cheeks, chestnut flank patches) are hidden for females.
 */
public class ZebraFinchModel extends EntityModel<ZebraFinch> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "zebra_finch"), "main");

    private final ModelPart root;
    private final ModelPart body, head, leftLeg, rightLeg, leftWing, rightWing, tail;
    private final ModelPart[] maleOnly;

    public ZebraFinchModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.tail = body.getChild("tail");
        this.leftWing = body.getChild("left_wing");
        this.rightWing = body.getChild("right_wing");
        this.maleOnly = new ModelPart[]{
                head.getChild("cheek_la"), head.getChild("cheek_lb"),
                head.getChild("cheek_ra"), head.getChild("cheek_rb"),
                body.getChild("flank_l"), body.getChild("flank_r")
        };
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition pd = mesh.getRoot();

        // ---------------- BODY
        PartDefinition body = pd.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -4F, -5F, 8F, 8F, 10F),
                PartPose.offsetAndRotation(0F, 15F, 0F, -0.6F, 0F, 0F));
        body.addOrReplaceChild("belly",
                CubeListBuilder.create().texOffs(20, 108).addBox(-3.5F, 4F, -4.5F, 7F, 1F, 9F), PartPose.ZERO);
        body.addOrReplaceChild("bib_top",
                CubeListBuilder.create().texOffs(0, 88).addBox(-3F, -3F, -6F, 6F, 3F, 1F), PartPose.ZERO);
        body.addOrReplaceChild("bib",
                CubeListBuilder.create().texOffs(16, 88).addBox(-3F, 0F, -6F, 6F, 3F, 1F), PartPose.ZERO);
        body.addOrReplaceChild("flank_l",
                CubeListBuilder.create().texOffs(0, 108).addBox(4F, 1F, -4F, 1F, 3F, 7F), PartPose.ZERO);
        body.addOrReplaceChild("flank_r",
                CubeListBuilder.create().texOffs(0, 108).addBox(-5F, 1F, -4F, 1F, 3F, 7F), PartPose.ZERO);

        // ---------------- TAIL (centre + 2 outer feathers)
        PartDefinition tail = body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(0, 42).addBox(-3F, -1F, 0F, 6F, 2F, 10F),
                PartPose.offsetAndRotation(0F, -2F, 5F, 0.3F, 0F, 0F));
        tail.addOrReplaceChild("tail_l",
                CubeListBuilder.create().texOffs(38, 96).addBox(0F, -1F, 0F, 1F, 2F, 9F),
                PartPose.offsetAndRotation(3F, 0F, 0F, 0F, -0.15F, 0F));
        tail.addOrReplaceChild("tail_r",
                CubeListBuilder.create().texOffs(38, 96).addBox(-1F, -1F, 0F, 1F, 2F, 9F),
                PartPose.offsetAndRotation(-3F, 0F, 0F, 0F, 0.15F, 0F));

        // ---------------- WINGS (main + covert layer + flight-feather strip)
        PartDefinition rw = body.addOrReplaceChild("right_wing",
                CubeListBuilder.create().texOffs(0, 56).addBox(-1F, 0F, 0F, 2F, 4F, 11F),
                PartPose.offset(-5F, -3F, -4F));
        rw.addOrReplaceChild("covert",
                CubeListBuilder.create().texOffs(22, 96).addBox(-2F, 0F, 1F, 1F, 2F, 6F), PartPose.ZERO);
        rw.addOrReplaceChild("feathers",
                CubeListBuilder.create().texOffs(0, 96).addBox(-2F, 2F, 2F, 1F, 2F, 9F), PartPose.ZERO);
        PartDefinition lw = body.addOrReplaceChild("left_wing",
                CubeListBuilder.create().texOffs(28, 56).addBox(-1F, 0F, 0F, 2F, 4F, 11F),
                PartPose.offset(5F, -3F, -4F));
        lw.addOrReplaceChild("covert",
                CubeListBuilder.create().texOffs(22, 96).addBox(1F, 0F, 1F, 1F, 2F, 6F), PartPose.ZERO);
        lw.addOrReplaceChild("feathers",
                CubeListBuilder.create().texOffs(0, 96).addBox(1F, 2F, 2F, 1F, 2F, 9F), PartPose.ZERO);

        // ---------------- HEAD (core + crown + round cheeks + eyes + tapered beak)
        PartDefinition head = pd.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 20).addBox(-3F, -3F, -3F, 6F, 6F, 6F),
                PartPose.offset(0F, 8.5F, -4.5F));
        head.addOrReplaceChild("crown",
                CubeListBuilder.create().texOffs(18, 80).addBox(-2F, -4F, -2F, 4F, 1F, 5F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_la",
                CubeListBuilder.create().texOffs(0, 80).addBox(3F, 0F, -2F, 1F, 3F, 3F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_lb",
                CubeListBuilder.create().texOffs(10, 80).addBox(4F, 0.5F, -1.5F, 1F, 2F, 2F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_ra",
                CubeListBuilder.create().texOffs(0, 80).addBox(-4F, 0F, -2F, 1F, 3F, 3F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_rb",
                CubeListBuilder.create().texOffs(10, 80).addBox(-5F, 0.5F, -1.5F, 1F, 2F, 2F), PartPose.ZERO);
        head.addOrReplaceChild("eye_l",
                CubeListBuilder.create().texOffs(38, 80).addBox(3F, -1F, -2F, 1F, 1F, 1F), PartPose.ZERO);
        head.addOrReplaceChild("eye_r",
                CubeListBuilder.create().texOffs(38, 80).addBox(-4F, -1F, -2F, 1F, 1F, 1F), PartPose.ZERO);
        head.addOrReplaceChild("beak_base",
                CubeListBuilder.create().texOffs(0, 34).addBox(-1.5F, 0F, -5F, 3F, 2F, 2F), PartPose.ZERO);
        head.addOrReplaceChild("beak_tip",
                CubeListBuilder.create().texOffs(14, 34).addBox(-1F, 0.5F, -7F, 2F, 1F, 2F), PartPose.ZERO);
        head.addOrReplaceChild("beak_lower",
                CubeListBuilder.create().texOffs(14, 34).addBox(-1F, 2F, -5F, 2F, 1F, 2F), PartPose.ZERO);

        // ---------------- LEGS with three toes + back toe
        for (String side : new String[]{"left", "right"}) {
            float x = side.equals("left") ? 2F : -2F;
            PartDefinition leg = pd.addOrReplaceChild(side + "_leg",
                    CubeListBuilder.create().texOffs(24, 34).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F),
                    PartPose.offset(x, 19F, 1F));
            leg.addOrReplaceChild("toe_m", CubeListBuilder.create().texOffs(30, 34)
                    .addBox(-0.5F, -0.5F, -3.5F, 1F, 1F, 4F), PartPose.offset(0F, 4.5F, 0F));
            leg.addOrReplaceChild("toe_a", CubeListBuilder.create().texOffs(30, 34)
                    .addBox(-0.5F, -0.5F, -3.5F, 1F, 1F, 4F), PartPose.offsetAndRotation(0F, 4.5F, 0F, 0F, 0.5F, 0F));
            leg.addOrReplaceChild("toe_b", CubeListBuilder.create().texOffs(30, 34)
                    .addBox(-0.5F, -0.5F, -3.5F, 1F, 1F, 4F), PartPose.offsetAndRotation(0F, 4.5F, 0F, 0F, -0.5F, 0F));
            leg.addOrReplaceChild("toe_back", CubeListBuilder.create().texOffs(30, 34)
                    .addBox(-0.5F, -0.5F, 0F, 1F, 1F, 2F), PartPose.offset(0F, 4.5F, 0F));
        }

        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(ZebraFinch entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        boolean male = !entity.isFemale();
        for (ModelPart p : maleOnly) {
            p.visible = male;
        }

        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);

        // ageInTicks carries the flap angle (see renderer.getBob)
        if (entity.isFlying()) {
            float a = 0.15F + ageInTicks * 0.55F;
            this.rightWing.zRot = a;
            this.leftWing.zRot = -a;
            this.body.xRot = -0.35F;
            this.leftLeg.xRot = 0.6F;
            this.rightLeg.xRot = 0.6F;
        } else {
            this.rightWing.zRot = 0.04F;
            this.leftWing.zRot = -0.04F;
            this.body.xRot = -0.6F;
            this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
            this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
