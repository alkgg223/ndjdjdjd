package com.zebrafinch.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;

public class FinchGoals {

    /** Nearest tree top (air block above leaves) within 16 blocks; falls back to the ground next to the bird. */
    @Nullable
    static BlockPos findNestSite(ServerLevel level, BlockPos origin) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int r = 16;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos top = new BlockPos(x, y - 1, z);
                if (!level.getBlockState(top).is(BlockTags.LEAVES)) continue;
                BlockPos site = top.above();
                if (!level.getBlockState(site).isAir()) continue;
                double d = site.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = site;
                }
            }
        }
        if (best != null) {
            return best;
        }
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-3, -1, -3), origin.offset(3, 2, 3))) {
            if (level.getBlockState(p).isAir()
                    && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), Direction.UP)) {
                return p.immutable();
            }
        }
        return null;
    }

    /** Normal love-mode pairing, but instead of an instant baby the pair goes to build a nest. */
    public static class PairGoal extends BreedGoal {
        private final ZebraFinch finch;

        public PairGoal(ZebraFinch finch, double speed) {
            super(finch, speed);
            this.finch = finch;
        }

        @Override
        protected void breed() {
            if (this.partner == null || !(this.level instanceof ServerLevel server)) {
                return;
            }
            this.finch.setAge(6000);
            this.partner.setAge(6000);
            this.finch.resetLove();
            this.partner.resetLove();
            BlockPos site = findNestSite(server, this.finch.blockPosition());
            if (site != null) {
                this.finch.setNestTarget(site);
                if (this.partner instanceof ZebraFinch other) {
                    other.setNestTarget(site);
                }
            }
        }
    }

    /** Fly to the tree top and place the nest block. */
    public static class BuildNestGoal extends Goal {
        private final ZebraFinch finch;
        private int timeout;

        public BuildNestGoal(ZebraFinch finch) {
            this.finch = finch;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return finch.getNestTarget() != null && !finch.isBaby();
        }

        @Override
        public boolean canContinueToUse() {
            return finch.getNestTarget() != null && timeout < 600;
        }

        @Override
        public void start() {
            timeout = 0;
        }

        @Override
        public void stop() {
            if (timeout >= 600) {
                finch.setNestTarget(null);
            }
        }

        @Override
        public void tick() {
            BlockPos target = finch.getNestTarget();
            if (target == null) return;
            timeout++;
            Vec3 c = Vec3.atCenterOf(target);
            finch.getLookControl().setLookAt(c.x, c.y, c.z);
            if (timeout % 10 == 1 || finch.getNavigation().isDone()) {
                finch.getNavigation().moveTo(c.x, c.y, c.z, 1.2D);
            }
            if (finch.distanceToSqr(c) < 4.0D) {
                Level level = finch.level();
                if (level.getBlockState(target).isAir()) {
                    BlockState nest = ModBlocks.NEST.get().defaultBlockState();
                    if (nest.canSurvive(level, target)) {
                        level.setBlockAndUpdate(target, nest);
                        level.playSound(null, target, SoundType.GRASS.getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
                    }
                }
                finch.setNestTarget(null);
            }
        }
    }

    /** Adult finches fly close to the fox and throw droppings at it. */
    public static class DefendNestGoal extends Goal {
        private final ZebraFinch finch;
        private int cooldown;

        public DefendNestGoal(ZebraFinch finch) {
            this.finch = finch;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = finch.getDefendTarget();
            return t != null && t.isAlive() && !finch.isBaby();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            cooldown = 10 + finch.getRandom().nextInt(10);
        }

        @Override
        public void tick() {
            LivingEntity target = finch.getDefendTarget();
            if (target == null) return;
            finch.getLookControl().setLookAt(target, 30.0F, 30.0F);
            double dist = finch.distanceTo(target);
            if (dist > 7.0D) {
                finch.getNavigation().moveTo(target.getX(), target.getY() + 2.0D, target.getZ(), 1.3D);
            } else {
                finch.getNavigation().stop();
            }
            if (--cooldown <= 0 && dist < 14.0D && finch.hasLineOfSight(target)) {
                throwDropping(target);
                cooldown = 20 + finch.getRandom().nextInt(20);
            }
        }

        private void throwDropping(LivingEntity target) {
            Level level = finch.level();
            FinchDropping drop = new FinchDropping(level, finch);
            drop.setPos(finch.getX(), finch.getEyeY() - 0.1D, finch.getZ());
            double dx = target.getX() - finch.getX();
            double dy = target.getY() + target.getBbHeight() * 0.6D - drop.getY();
            double dz = target.getZ() - finch.getZ();
            drop.shoot(dx, dy, dz, 1.6F, 1.0F);
            level.addFreshEntity(drop);
            finch.playSound(ModSounds.MEEP.get(), 0.8F, 1.5F);
        }
    }
}
