package com.zebrafinch.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Fox;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class FinchNestBlockEntity extends BlockEntity {
    /** one egg hatches every minute */
    public static final int HATCH_TICKS = 20 * 60;
    /** a fox that stays next to the nest this long destroys it */
    public static final int FOX_DESTROY_TICKS = 20 * 15;
    /** "next to the nest": horizontal / vertical distance (the nest sits in a tree top) */
    private static final double NEAR_HORIZONTAL = 4.0D;
    private static final double NEAR_VERTICAL = 10.0D;
    /** adult finches start throwing droppings when a fox gets this close */
    private static final double ALERT_RANGE = 10.0D;
    public static final String SCARED_KEY = "zebrafinch_scared_until";

    private int hatchTimer;
    private int foxTicks;

    public FinchNestBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.NEST.get(), pos, state);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("HatchTimer", hatchTimer);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        hatchTimer = tag.getInt("HatchTimer");
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, FinchNestBlockEntity be) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        be.tickFox(server, pos);
        BlockState current = server.getBlockState(pos);
        if (!current.is(state.getBlock())) {
            return; // destroyed by the fox
        }
        int eggs = current.getValue(FinchNestBlock.EGGS);
        if (eggs <= 0) {
            return;
        }
        if (++be.hatchTimer >= HATCH_TICKS) {
            be.hatchTimer = 0;
            server.setBlock(pos, current.setValue(FinchNestBlock.EGGS, eggs - 1), 3);
            be.hatch(server, pos);
            be.setChanged();
        } else if (be.hatchTimer % 200 == 0) {
            be.setChanged();
        }
    }

    private void hatch(ServerLevel level, BlockPos pos) {
        ZebraFinch baby = ModEntities.ZEBRA_FINCH.get().create(level);
        if (baby != null) {
            baby.moveTo(pos.getX() + 0.5D, pos.getY() + 0.25D, pos.getZ() + 0.5D, level.random.nextFloat() * 360F, 0F);
            baby.setBaby(true);
            baby.setFemale(level.random.nextBoolean());
            baby.setWhite(level.random.nextInt(12) == 0);
            level.addFreshEntity(baby);
        }
        level.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS, 0.7F, 1.2F);
        level.playSound(null, pos, ModSounds.MEEP.get(), SoundSource.NEUTRAL, 0.5F, 1.6F);
    }

    private void tickFox(ServerLevel level, BlockPos pos) {
        if (level.getGameTime() % 10L != 0L) {
            return;
        }
        AABB area = new AABB(pos).inflate(ALERT_RANGE + 6.0D, 14.0D, ALERT_RANGE + 6.0D);
        List<Fox> foxes = level.getEntitiesOfClass(Fox.class, area);
        Vec3 nest = Vec3.atCenterOf(pos);
        boolean near = false;

        for (Fox fox : foxes) {
            double dx = fox.getX() - nest.x;
            double dz = fox.getZ() - nest.z;
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double vertical = Math.abs(fox.getY() - pos.getY());
            boolean scared = fox.getPersistentData().getLong(SCARED_KEY) > level.getGameTime();

            if (scared) {
                // keep a frightened fox running away from the nest
                if (horizontal < 14.0D && level.getGameTime() % 20L == 0L) {
                    Vec3 away = DefaultRandomPos.getPosAway(fox, 20, 8, nest);
                    if (away != null) {
                        fox.getNavigation().moveTo(away.x, away.y, away.z, 1.5D);
                    }
                }
                continue;
            }

            if (horizontal <= ALERT_RANGE && vertical <= 14.0D) {
                alertFinches(level, pos, fox);
            }
            if (horizontal <= NEAR_HORIZONTAL && vertical <= NEAR_VERTICAL) {
                near = true;
                fox.getNavigation().moveTo(nest.x, fox.getY(), nest.z, 1.0D);
                fox.getLookControl().setLookAt(nest.x, nest.y, nest.z);
            }
        }

        foxTicks = near ? foxTicks + 10 : 0;
        if (foxTicks >= FOX_DESTROY_TICKS) {
            foxTicks = 0;
            level.playSound(null, pos, SoundEvents.FOX_EAT, SoundSource.NEUTRAL, 1.0F, 1.0F);
            level.destroyBlock(pos, false);
        }
    }

    private void alertFinches(ServerLevel level, BlockPos pos, Fox fox) {
        List<ZebraFinch> birds = level.getEntitiesOfClass(ZebraFinch.class,
                new AABB(pos).inflate(24.0D), b -> !b.isBaby());
        for (ZebraFinch bird : birds) {
            bird.setDefendTarget(fox);
        }
    }
}
