package com.zebrafinch.mod;

import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ZebraFinchMod.MODID);

    public static final DeferredBlock<FinchNestBlock> NEST = BLOCKS.register("finch_nest",
            () -> new FinchNestBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD)
                    .strength(0.4F)
                    .sound(SoundType.GRASS)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));
}
