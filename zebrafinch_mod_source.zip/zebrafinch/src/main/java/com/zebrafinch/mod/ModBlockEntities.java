package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, ZebraFinchMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FinchNestBlockEntity>> NEST =
            BLOCK_ENTITIES.register("finch_nest", () ->
                    BlockEntityType.Builder.of(FinchNestBlockEntity::new, ModBlocks.NEST.get()).build(null));
}
